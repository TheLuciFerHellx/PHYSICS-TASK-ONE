using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIMangerOFTASK4 : MonoBehaviour
{
    [SerializeField]
    public List<screenDataTASK4> screen = new List<screenDataTASK4>();

    private screenDataTASK4 currentScreen;
    // public GameObject player;

    void Start()
    {

        HideAllScreens();
        showScreen(screensTASK4.HomePage);
    }

    // public void showScreen(screensTASK4 type)
    // {
    //     if(currentScreen != null)
    //     {
    //         currentScreen.baseScreen.Hide();
    //     }

    //     screenDataTASK4 screenToShow = screen.Find(x => x.screenType == type);

    //     if(screenToShow != null)
    //     {
    //         currentScreen = screenToShow;
    //         screenToShow.baseScreen.Show();
    //     }
    //     else
    //     {
    //         Debug.Log("Screen Not Found");
    //     }
    // }

    public void showScreen(screensTASK4 type) 
{
    // 1. Use the ?. operator to safely call Hide only if both currentScreen and baseScreen exist
    currentScreen?.baseScreen?.Hide();

    // 2. Find the next screen
    screenDataTASK4 screenToShow = screen.Find(x => x.screenType == type);

    // 3. Check if the screen was actually found AND has a component assigned
    if (screenToShow != null && screenToShow.baseScreen != null) 
    {
        currentScreen = screenToShow;
        currentScreen.baseScreen.Show();
    } 
    else 
    {
        Debug.LogError($"Screen of type {type} not found or UIBase is missing in Inspector!");
    }
}

    // private void HideAllScreens()
    // {
    //     foreach(var screen in screen)
    //     {
    //         screen.baseScreen.Hide();
    //     }
    // }

    private void HideAllScreens()
{
    foreach(var s in screen)
    {
        // Add this check to prevent the crash
        if (s != null && s.baseScreen != null)
        {
            s.baseScreen.Hide();
        }
        else
        {
            Debug.LogWarning("Found an unassigned screen in the UIManager list!");
        }
    }
}

}
    public enum screensTASK4
    {
        HomePage,
        GamePlay,
        Settings,
        Restart
    }

    [Serializable]
    public class screenDataTASK4
    {
        public screensTASK4 screenType;
        public UIBase baseScreen;
    }
