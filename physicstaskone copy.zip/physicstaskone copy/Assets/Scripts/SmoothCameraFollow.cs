using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class SmoothCameraFollow : MonoBehaviour
{
    
    public Transform player;
    public float Speed =5f;
    public Vector3 offset;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    private void LateUpdate() 
    {
        transform.position = Vector3.MoveTowards(transform.position, player.position + offset, Speed * Time.deltaTime);    
    }
}
