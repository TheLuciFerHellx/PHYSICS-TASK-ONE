using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIGameScreen : MonoBehaviour
{
    public UIMangerOFTASK4 uIManager;
    public GameObject player;
    public void ShowSettingView()
    {
        player.GetComponent<PlayerController>().enabled = true;
        uIManager.showScreen(screensTASK4.Settings);
    }
}
