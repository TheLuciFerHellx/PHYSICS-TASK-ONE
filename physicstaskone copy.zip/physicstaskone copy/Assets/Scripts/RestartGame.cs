using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RestartGame : MonoBehaviour
{
  public UIMangerOFTASK4 uIManager;
    public GameObject player;
    public SpriteRenderer sr;

    public Infinitybuildings infinitybuildings;

    void Start()
    {
        sr = player.GetComponent<SpriteRenderer>();
    }
    public void ShowRestartView()
    {
        Time.timeScale =1;
        player.GetComponent<PlayerController>().enabled = true;
        sr.color = Color.white;
        player.transform.position = new Vector3(player.transform.position.x + 5, 3, player.transform.position.z);
        uIManager.showScreen(screensTASK4.GamePlay);
        
    }
}
