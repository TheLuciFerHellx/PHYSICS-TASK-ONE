using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UISettingScreen : MonoBehaviour
{
     public UIMangerOFTASK4 uIManager;
      public GameObject player;

      public Canvas setting;
    // public GameObject builder;

    public Infinitybuildings infinitybuildings;

    // public void ShowSetttingsiew()
    // {
    //     player.GetComponent<PlayerController>().enabled = false;
    //     // builder.GetComponent<Infinitybuildings>().enabled = false;
    //     infinitybuildings.ToggleSpawning(false);
    //     uIManager.showScreen(screensTASK4.Settings);
    // }

    // public void hideSettingView()
    // {
    //     player.GetComponent<PlayerController>().enabled = true;
    //     // builder.GetComponent<Infinitybuildings>().enabled = true;
    //     infinitybuildings.ToggleSpawning(true);
    //     uIManager.showScreen(screensTASK4.GamePlay);
    // }

    public void ShowSreen()
    {
        player.GetComponent<PlayerController>().enabled = false;
        infinitybuildings.ToggleSpawning(false);
        setting.enabled = true;
    }

    public void HideScreen()
    {
         player.GetComponent<PlayerController>().enabled = true;
          infinitybuildings.ToggleSpawning(true);
        setting.enabled = false;
    }
}
