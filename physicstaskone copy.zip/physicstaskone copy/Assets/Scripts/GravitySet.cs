using System.Collections;
using System.Collections.Generic;
using UnityEditor.Callbacks;
using UnityEngine;
using UnityEngine.UI;

public class GravitySet : MonoBehaviour
{
    public Toggle low;
    public Toggle mid;
    public Toggle high;
    public Rigidbody2D rb;
    // Start is called before the first frame update
    // void Start()
    // {
    //     rb = GetComponent<Rigidbody2D>();
    // }

    // // Update is called once per frame
     void Start()
    {
        // Get the Rigidbody2D component if not assigned in inspector
        if (rb == null) rb = GetComponent<Rigidbody2D>();

        // Add listeners to detect when each toggle is clicked
        low.onValueChanged.AddListener(delegate { SetGravity(); });
        mid.onValueChanged.AddListener(delegate { SetGravity(); });
        high.onValueChanged.AddListener(delegate { SetGravity(); });
    }

    void SetGravity()
    {
        
        if (low.isOn) 
        {
            rb.gravityScale = 0.5f;
        }
        else if (mid.isOn)
        {
            rb.gravityScale = 1.0f;
        }
        else if (high.isOn) 
        {
            rb.gravityScale = 2.0f;
        }
    }
}
