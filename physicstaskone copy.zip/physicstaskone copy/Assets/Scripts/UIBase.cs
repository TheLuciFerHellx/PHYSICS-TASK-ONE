using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIBase : MonoBehaviour
{
    // private Canvas canvas;

    // void Start()
    // {
    //     canvas = GetComponent<Canvas>();
    // }
    // public virtual void Show()
    // {
    //     canvas.enabled = true;
    // }

    // public virtual void Hide()
    // {
    //     canvas.enabled = false;
    // }
    private Canvas canvas;

    // Use Awake to ensure this happens BEFORE the UIManager calls Hide() in Start()
    void Awake()
    {
        canvas = GetComponent<Canvas>();
        
        // Safety check: show an error if the script isn't on a Canvas object
        if (canvas == null) 
        {
            Debug.LogError($"Canvas component missing on {gameObject.name}!");
        }
    }

    public virtual void Show()
    {
        if (canvas != null) canvas.enabled = true;
    }

    public virtual void Hide()
    {
        if (canvas != null) canvas.enabled = false;
    }
}
