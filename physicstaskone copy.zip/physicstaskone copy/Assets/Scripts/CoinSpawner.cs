using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;

public class CoinSpawner : MonoBehaviour
{
    public GameObject CoinPrefab;
    public Vector3 offset;
    public Vector3 spawnPoint;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SpawnCoins());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator SpawnCoins()
    {
        while(true)
        {
            SpawnCoin();
            yield return new WaitForSeconds(1f);
        }
    }

    public void SpawnCoin()
    {
        Instantiate(CoinPrefab, spawnPoint, quaternion.identity);
        spawnPoint += new Vector3(20f, 0,0);
    }
}
