using System.Collections;
using System.Collections.Generic;
using UnityEditor.Callbacks;
using UnityEngine;

public class UIHomeScreen : MonoBehaviour
{
     public UIMangerOFTASK4 uIManager;
    public GameObject player;
    public GameObject builder;
    public Rigidbody2D rb;
    void Start()
    {
        rb = player.GetComponent<Rigidbody2D>();
    }
    public void ShowGameView()
    {
        Time.timeScale = 1;
        player.GetComponent<PlayerController>().enabled = true;
        rb.gravityScale =1;
        builder.GetComponent<Infinitybuildings>().enabled = true;
        uIManager.showScreen(screensTASK4.GamePlay);
    }
}
