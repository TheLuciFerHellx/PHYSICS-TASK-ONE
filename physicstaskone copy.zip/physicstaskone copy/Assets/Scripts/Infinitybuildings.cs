// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;
// using UnityEngine.Video;

// public class Infinitybuildings : MonoBehaviour
// {
//     public GameObject[] BuildingsPrefab;
//     public float nextPosiotn =10f;
//     public int spawnInterval = 1;
//     public Vector3 Nextspawnpoint = Vector3.zero;
//      private float timeToDestroy = 20f; 
//      private float IntervalBeforeDestroyimgNextBuilding = 10;
//      public List<GameObject> garbageCollector = new List<GameObject>();

//      private Coroutine spawnCoroutine;
//     private Coroutine destroyCoroutine;
//     // Start is called before the first frame update
//     void Start()
//     {
//         // for(int i=1; i<=10; i++)
//         // {
//         //     SpwanBuildings();
//         // }       

//         // StartCoroutine(SpawnRoutine()); 
//         // StartCoroutine(Destroyer());

//         ToggleSpawning(true);
//     }

//     public void ToggleSpawning(bool enable)
//     {
//         this.enabled = enable; // Toggles OnDisable/OnEnable behaviour if needed
//         if (enable)
//         {
//             spawnCoroutine = StartCoroutine(SpawnRoutine());
//             destroyCoroutine = StartCoroutine(Destroyer());
//         }
//         else
//         {
//             if (spawnCoroutine != null) StopCoroutine(spawnCoroutine);
//             if (destroyCoroutine != null) StopCoroutine(destroyCoroutine);
//         }
//     }
//     IEnumerator SpawnRoutine()
//     {
//         while (true) // Infinite loop
//         {
//             SpwanBuildings();
//             yield return new WaitForSeconds(spawnInterval); // Wait before next spawn
//         }
//     }
//     public void SpwanBuildings()
//     {
//         int index = Random.Range(0, BuildingsPrefab.Length);
//         GameObject building = Instantiate(BuildingsPrefab[index], Nextspawnpoint, Quaternion.identity);

//         garbageCollector.Add(building);
//         Nextspawnpoint += new Vector3(nextPosiotn,0, 0);
//     }

//     public IEnumerator Destroyer()
//     {
//         yield return new WaitForSeconds(timeToDestroy);

//         while(garbageCollector.Count > 0)
//         {
//             GameObject DestroyOldbuilding = garbageCollector[0];
        
//             if(DestroyOldbuilding != null)
//             {
//                 Destroy(DestroyOldbuilding);
//             }

//             garbageCollector.RemoveAt(0);

//             yield return new WaitForSeconds(IntervalBeforeDestroyimgNextBuilding);
//         }
//     }
// }


using System.Collections;
using System.Collections.Generic;
using JetBrains.Annotations;
using UnityEngine;

public class Infinitybuildings : MonoBehaviour
{
    [Header("Settings")]
    public GameObject[] BuildingsPrefab;
    public float nextPosiotn = 10f;
    public int spawnInterval = 1;
    public Vector3 Nextspawnpoint = Vector3.zero;
    public float DistanceToDisable = 40f; // Time before reusing a building
    public GameObject player;
    
    // Pool to hold inactive objects
public List<GameObject> pool = new List<GameObject>();
    private Coroutine spawnCoroutine;

    void Start()
    {
        ToggleSpawning(true);
    }

    public void ToggleSpawning(bool enable)
    {
        if (enable)
        {
            if (spawnCoroutine == null)
                spawnCoroutine = StartCoroutine(SpawnRoutine());
        }
        else
        {
            if (spawnCoroutine != null)
            {
                StopCoroutine(spawnCoroutine);
                spawnCoroutine = null;
            }
        }
    }

    IEnumerator SpawnRoutine()
    {
        while (true)
        {
            SpawnBuilding();
            yield return new WaitForSeconds(spawnInterval);
        }
    }

    public void SpawnBuilding()
    {
        GameObject building = GetPooledObject();

        if (building != null)
        {
            building.transform.position = Nextspawnpoint;
            building.SetActive(true);
            Nextspawnpoint += new Vector3(nextPosiotn, 0, 0);
            
            // Start coroutine to return this specific building to pool
            StartCoroutine(DisableBuildingAfterTime(building));
        }
    }

    // Object Pool Logic: Get inactive or Create new
    GameObject GetPooledObject()
    {
        for (int i = 0; i < pool.Count; i++)
        {
            if (!pool[i].activeInHierarchy)
            {
                return pool[i];
            }
        }

        // If no inactive object found, expand pool
        int index = Random.Range(0, BuildingsPrefab.Length);
        GameObject obj = Instantiate(BuildingsPrefab[index]);
        obj.SetActive(false);
        pool.Add(obj);
        // if(Vector3.Distance(obj.transform.position, player.transform.position) > 20f)
        // {
        // }
        return obj;
    }

    
    // Instead of Destroying, we disable the object
    IEnumerator DisableBuildingAfterTime(GameObject building)
    {
        // yield return new WaitForSeconds(timeToDisable);
        // if (building != null)
        // {
        //         building.SetActive(false);
        //     // if(Vector3.Distance(player.transform.position , building.transform.position) > 20f)
        //     // {
        //     // }
        // }

         while (building.activeSelf)
        {
            if (player.transform.position.x - building.transform.position.x > DistanceToDisable)
            {
                building.SetActive(false);
                yield break; // Exit the coroutine
            }
            yield return new WaitForSeconds(0.1f); 
    }
    }
}
