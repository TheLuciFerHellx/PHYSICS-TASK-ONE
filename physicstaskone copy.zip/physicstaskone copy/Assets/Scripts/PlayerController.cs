using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.Serialization;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.Windows.Speech;

public class PlayerController : MonoBehaviour
{
    public GameObject Player;

    public SpriteRenderer sr;
    private Rigidbody2D rb;
    public int maxJump= 2;
    public int jumpleft;
    public float speed = 5f;
    public float JumpPower = 5f;
    // Start is called before the first frame update
    public float xInput;
    private bool jumpRequested;

    public UIMangerOFTASK4 uIManager;
    // public GameObject gameOverSCreen;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
        // gameOverSCreen.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        // xInput = Input.GetAxisRaw("Horizontal");
        // transform.Translate(Vector3.right * xInput * speed * Time.deltaTime);


        // Player.transform.position += Vector3.right * speed * Time.deltaTime; 
        // if(Input.GetMouseButtonDown(0) && jumpleft > 0)
        // {
        //    UnityEngine.Debug.Log("JUMP");
        //     rb.AddForce(Vector3.up * JumpPower , ForceMode2D.Impulse);
        //     jumpleft--;
        // }

        // if(Input.GetKeyDown(KeyCode.Space) && jumpleft > 0)
        // {
        //     rb.AddForce(Vector3.up * JumpPower , ForceMode2D.Impulse);
        //     jumpleft--;
        // }

         xInput = Input.GetAxis("Horizontal");

        if (Input.GetKeyDown(KeyCode.Space) && jumpleft > 0) {
            jumpRequested = true;
        }
    }

    void FixedUpdate() 
    {
        
        rb.velocity = new Vector2(xInput * speed, rb.velocity.y);

        if (jumpRequested) 
        {    
            rb.velocity = new Vector2(rb.velocity.x, 0); 
            rb.AddForce(Vector2.up * JumpPower, ForceMode2D.Impulse);
            jumpleft--;
            jumpRequested = false;
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.CompareTag("DEAD"))
        {
            UnityEngine.Debug.Log("GAME OVER");
            Time.timeScale =0;
            sr.color = Color.red;
            // gameOverSCreen.SetActive(true);
            // player.GetComponent<PlayerController>().enabled = false;
            
            uIManager.showScreen(screensTASK4.Restart);
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("ground"))
        {
            jumpleft = maxJump;
        }
    }

}
