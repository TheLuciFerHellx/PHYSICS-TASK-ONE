using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Infinitybuildings : MonoBehaviour
{
    [Header("Settings")]
    public GameObject[] BuildingsPrefab;
    public float nextPosition = 10f; // Fixed typo
    public Vector3 Nextspawnpoint = Vector3.zero;
    public float DistanceToDisable = 40f; 
    public GameObject player;

    public int poolSize = 10;
    
    public List<GameObject> pool = new List<GameObject>();

    void Start()
    {
        // Call the spawn function once at the start
        SpawnTenBuildings();
    }

    public void SpawnTenBuildings()
    {
        for (int i = 0; i < poolSize; i++)
        {
            SpawnBuilding();
        }
    }

    public void SpawnBuilding()
    {
        GameObject building = GetPooledObject();

        if (building != null)
        {
            building.transform.position = Nextspawnpoint;
            building.SetActive(true);
            
            // Move the spawn point forward for the next building
            Nextspawnpoint += new Vector3(nextPosition, 0, 0);
            
            StartCoroutine(DisableBuildingAfterTime(building));
        }
    }

    GameObject GetPooledObject()
    {
        for (int i = 0; i < pool.Count; i++)
        {
            if (!pool[i].activeInHierarchy)
            {
                return pool[i];
            }
        }

        int index = Random.Range(0, BuildingsPrefab.Length);
        GameObject obj = Instantiate(BuildingsPrefab[index]);
        obj.SetActive(false);
        pool.Add(obj);
      
        return obj;
    }

    // IEnumerator DisableBuildingAfterTime(GameObject building)
    // {
    //     while (building.activeSelf)
    //     {
    //         // If player passes the building by the set distance, disable it
    //         if (player.transform.position.x - building.transform.position.x > DistanceToDisable)
    //         {
    //             building.SetActive(false);
    //             yield break; 
    //         }
    //         yield return new WaitForSeconds(0.5f); // Check every half second to save performance
    //     }
    // }
     IEnumerator DisableBuildingAfterTime(GameObject building)
    {
        while (true)
        {
            // Check if the building is far behind the player
            if (player.transform.position.x - building.transform.position.x > DistanceToDisable)
            {
                // 1. Hide it briefly
                building.SetActive(false);

                // 2. Move it to the NEW front position
                building.transform.position = Nextspawnpoint;

                // 3. Update the global spawn point for the NEXT building
                Nextspawnpoint += new Vector3(nextPosition, 0, 0);

                // 4. Turn it back on at the new position
                building.SetActive(true);

                // The coroutine keeps running for this building at its new spot
            }
            
            // Check every 0.2 seconds to save CPU
            yield return new WaitForSeconds(0.2f); 
        }
    }
}
