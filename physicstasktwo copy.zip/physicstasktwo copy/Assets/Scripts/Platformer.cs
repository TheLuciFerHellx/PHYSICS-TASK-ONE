// using System.Collections;
// using System.Collections.Generic;
// using Unity.Mathematics;
// using UnityEngine;

// public class Platformer : MonoBehaviour
// {
//     public GameObject objPrefab;
//     public int poolsize = 10;
//     public float nextPosition = 10f;

//     public List<GameObject> pool;
//      public float DistanceToDisable = 40f; 

//     public GameObject player;


//     void Start()
//     {

//         pool = new List<GameObject>();
//         for(int i=0; i<poolsize ; i++)
//         {
//             GameObject obj = Instantiate(objPrefab);
//             obj.SetActive(false);
//             pool.Add(obj);
//         }
//         // Start after 0 seconds, repeat every 1 second
//         InvokeRepeating(nameof(SpawnObj), 0f, 1f);
//     }

//     void SpawnObj()
//     {
//         GameObject obj = GetPooledObject();
//         if(obj != null)
//         {
//             Vector3 spawnPos = new Vector3(transform.position.x + (Time.time * nextPosition), -9f, 0f);
//             obj.transform.position = spawnPos;
//             obj.SetActive(true);
            
//         }
//         // Calculate new position based on X offset and fixed Y/Z
        
//         // Use Instantiate to create the object
//         // Instantiate(objPrefab, spawnPos, Quaternion.identity);
//     }

//      GameObject GetPooledObject()
//     {
//         // 3. Reuse object
//         for (int i = 0; i < pool.Count; i++)
//         {
//             if (!pool[i].activeInHierarchy)
//             {
//                 return pool[i];
//             }
//         }
//         return null; // Pool full
//     }

//      IEnumerator DisableBuildingAfterTime(GameObject building)
//     {
//         while (true)
//         {   
//             Vector3 spawnPos = new Vector3(transform.position.x + (Time.time * nextPosition), -9f, 0f);
            
//             // Check if the building is far behind the player
//             if (player.transform.position.x - building.transform.position.x > DistanceToDisable)
//             {
//                 // 1. Hide it briefly
//                 building.SetActive(false);

//                 // 2. Move it to the NEW front position
//                 building.transform.position = spawnPos;

//                 // 3. Update the global spawn point for the NEXT building
//                 spawnPos += new Vector3(transform.position.x + (Time.time * nextPosition), -9f, 0f);

//                 // 4. Turn it back on at the new position
//                 building.SetActive(true);

//                 // The coroutine keeps running for this building at its new spot
//             }
            
//             // Check every 0.2 seconds to save CPU
//             yield return new WaitForSeconds(0.2f); 
//         }
//     }
// }
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platformer : MonoBehaviour 
{
    public GameObject objPrefab;
    public int poolSize = 10;
    public float nextPositionStep = 10f; // Distance between objects
    public float distanceToDisable = 40f;
    public GameObject player;

    private List<GameObject> pool;
    private float currentSpawnX; // Tracks the next available X position

    void Start() 
    {
        currentSpawnX = transform.position.x;
        pool = new List<GameObject>();

        for(int i = 0; i < poolSize; i++) 
        {
            GameObject obj = Instantiate(objPrefab);
            obj.SetActive(false);
            pool.Add(obj);
            
            StartCoroutine(CheckAndRecycle(obj)); 
        }

        // Spawn initial set and repeat
        InvokeRepeating(nameof(SpawnObj), 0f, 1f);
    }

    void SpawnObj() 
    {
        GameObject obj = GetPooledObject();
        if(obj != null) 
        {
           
            Vector3 spawnPos = new Vector3(currentSpawnX, -9f, 0f);
            obj.transform.position = spawnPos;
            obj.SetActive(true);
            
            
            currentSpawnX += nextPositionStep;
        }
    }

    GameObject GetPooledObject() 
    {
        for (int i = 0; i < pool.Count; i++) 
        {
            if (!pool[i].activeInHierarchy) return pool[i];
        }
        return null;
    }

    // Renamed for clarity: Handles disabling far-away objects
    IEnumerator CheckAndRecycle(GameObject platform) 
    {
        while (true) 
        {
            // If building is active and far behind the player, disable it
            if (platform.activeInHierarchy && 
                player.transform.position.x - platform.transform.position.x > distanceToDisable) 
            {
                platform.SetActive(false); // Return to pool
            }
            // Check every 0.2 seconds to save CPU
            yield return new WaitForSeconds(0.2f);
        }
    }
}
