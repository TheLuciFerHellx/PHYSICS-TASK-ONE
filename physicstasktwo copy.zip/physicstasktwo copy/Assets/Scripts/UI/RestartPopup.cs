using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartPopup : MonoBehaviour
{
    public UIManager uiManager; 
    
    // The specific canvas to show
    public Canvas HomeCanvas;
     public Canvas RestartCanvas;

    public GameObject player;

    public float upwardOffset = 2.0f;
    public float forwardXOffset = 2.0f;

    void Awake()
    {
        Time .timeScale = 0; //pause the game
        Debug.Log("Game is paused currently.");
    }
    public void Restartgame()
    {
        uiManager.DisableCanvas(HomeCanvas);
        uiManager.DisableCanvas(RestartCanvas);

         Vector3 spawnOffset = new Vector3(forwardXOffset, upwardOffset, 0);
        player.transform.position = player.transform.position + spawnOffset;

        Time.timeScale = 1;
        // Shows settings, hides others
        // uiManager.DisableCanvas(settingsCanvas); 
        // SceneManager.LoadScene("physics");  
    }
}
