using UnityEngine;
using System.Collections.Generic;

public class UIManager : MonoBehaviour
{
    // List of all Canvases to manage
    [SerializeField] private List<Canvas> allCanvases;

    // Call this to show a specific canvas and hide all others
    public void ShowCanvas(Canvas targetCanvas)
    {
        foreach (Canvas canvas in allCanvases)
        {
            // Set the Canvas component's enabled state
            canvas.enabled = (canvas == targetCanvas);
            
            // Optional: If you use CanvasGroups for fading, 
            // you can toggle them here as well.
        }
    }

    // Direct method to disable a specific Canvas by reference
    public void DisableCanvas(Canvas canvasToDisable)
    {
        canvasToDisable.enabled = false;
    }
}
