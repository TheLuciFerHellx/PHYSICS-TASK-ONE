using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mainMenu : MonoBehaviour
{
     public UIManager uiManager; 
    
    // The specific canvas to show
    public Canvas settingsCanvas;

    void Awake()
    {
        Time .timeScale = 0; //pause the game
        Debug.Log("Game is paused currently.");
    }
    public void Startgame()
    {
        Time.timeScale = 1;
        // Shows settings, hides others
        uiManager.DisableCanvas(settingsCanvas); 
    }
}
