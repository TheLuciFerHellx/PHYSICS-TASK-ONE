using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using Unity.VisualScripting.Dependencies.Sqlite;
using UnityEngine;
using UnityEngine.UIElements;

public class PlayerController : MonoBehaviour
{
    public DistanceJoint2D joint;
    public LineRenderer lineRenderer;
    public LayerMask GrappleLayer;

    public Camera MainCamera;
    public Rigidbody2D rb;
    private float xInput;
    public float LeftRightSwingPower = 1f;

    public float MaxDistanceToThrowGrapple = 10f;

      public UIManager uiManager; 
    
    // The specific canvas to show
    public Canvas RestartCanvas;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        joint.enabled = false;
        lineRenderer.positionCount = 0;
    }


    void FixedUpdate()
    {
          rb.AddForce(Vector2.right * xInput * LeftRightSwingPower);
    }

    // Update is called once per frame
    void Update()
    {
        xInput = Input.GetAxis("Horizontal");

        if(Input.GetMouseButtonDown(0))
        {
            ShootGrapple();
        }
        if(Input.GetKeyDown(KeyCode.Space))
        {
            ReleaseGrapple();
        }
        if(joint.enabled)
        {
            lineRenderer.SetPosition(0, transform.position);
        }

        if(Input.GetKey(KeyCode.UpArrow))
        {
            joint.distance -= 0.01f;
        }

        if(Input.GetKey(KeyCode.DownArrow))
        {
            joint.distance += 0.01f;
        }

      
    }

    // void ShootGrapple()
    // {
    //     Vector2 MousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
    //     Vector2 Direction = MousePos - (Vector2)transform.position;

    //     RaycastHit2D hit = Physics2D.Raycast(transform.position, Direction, MaxDistanceToThrowGrapple, GrappleLayer);

    //     if(hit.collider != null)
    //     {
    //         joint.enabled = true;
    //         joint.connectedAnchor = hit.collider.transform.InverseTransformPoint(hit.point);
    //         joint.enabled = true;
    //          if(hit.collider.gameObject.GetComponent<Rigidbody2D>() != null)
    //         {
    //             joint.autoConfigureConnectedAnchor = false;
    //             joint.connectedBody = hit.collider.gameObject.GetComponent<Rigidbody2D>();
    //         }

    //         lineRenderer.positionCount =2;
    //         lineRenderer.SetPosition(0, transform.position);
    //         lineRenderer.SetPosition(1, hit.point);
    //     }
    // }

    //  void ShootGrapple()
    // {
    //     Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        
    //     // Find nearest collider within 2 units of the click
    //     Collider2D hit = Physics2D.OverlapCircle(mousePos, 4f, GrappleLayer);

    //     if (hit != null)
    //     {
    //         Vector2 hitPoint = hit.ClosestPoint(mousePos);
            
    //         // Check max range from player
    //         if (Vector2.Distance(transform.position, hitPoint) <= MaxDistanceToThrowGrapple)
    //         {
    //             joint.enabled = true;
    //             joint.connectedAnchor = hit.transform.InverseTransformPoint(hitPoint);
    //             joint.connectedBody = hit.GetComponent<Rigidbody2D>();
    //             joint.distance = Vector2.Distance(transform.position, hitPoint);
                
    //             lineRenderer.positionCount = 2;
    //             lineRenderer.SetPosition(0, transform.position);
    //             lineRenderer.SetPosition(1, hitPoint);
    //         }
    //     }
    // }


    void ShootGrapple()
    {
    // 1. Find all grapple points within 'MaxDistanceToThrowGrapple' of the PLAYER
    Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, MaxDistanceToThrowGrapple, GrappleLayer);
    
    Collider2D closestHit = null;
    float closestDist = Mathf.Infinity;

    // 2. Loop to find the nearest one
    foreach (var hit in hits) {
        float dist = Vector2.Distance(transform.position, hit.transform.position);
        if (dist < closestDist) {
            closestDist = dist;
            closestHit = hit;
        }
    }

    // 3. Connect to the nearest target
    if (closestHit != null) {
        // Vector2 hitPoint = closestHit.ClosestPoint(transform.position);
         Vector2 hitPoint = closestHit.transform.position;
        
        joint.enabled = true;
        joint.connectedAnchor = closestHit.transform.InverseTransformPoint(hitPoint);
        joint.connectedBody = closestHit.GetComponent<Rigidbody2D>();
        joint.distance = closestDist;


        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0, transform.position);
        lineRenderer.SetPosition(1, hitPoint);
        lineRenderer.enabled = true;
    }
}
    void ReleaseGrapple()
    {
        joint.enabled = false;
        lineRenderer.positionCount = 0;
        joint.connectedBody = null;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Finish"))
        {
            Time.timeScale = 0;
            // UnityEngine.Debug.Log("GAME OVER");
            uiManager.ShowCanvas(RestartCanvas);
            Debug.Log("Collided with: " + collision.gameObject.tag);
        }
    }
}
