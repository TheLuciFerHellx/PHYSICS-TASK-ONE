using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour 
{
    public Transform target; // Drag your player here in the Inspector
    public Vector3 offset = new Vector3(0, 5, -10); // Adjust for desired distance
    public float smoothSpeed = 0.125f; // Value between 0 and 1 (lower is smoother)

    void LateUpdate() 
    {
        // The one-line smooth follow code
        transform.position = Vector3.Lerp(transform.position, target.position + offset, smoothSpeed);
    }
}
