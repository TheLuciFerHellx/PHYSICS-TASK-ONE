using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class DisplayAPIData : MonoBehaviour
{
    public TMP_InputField inputField;
    public TextMeshProUGUI pokeName;
    public TextMeshProUGUI pokeHeight;
    public TextMeshProUGUI pokeWeight;
    public TextMeshProUGUI pokeId;

    public TextMeshProUGUI pokeType;
    public string pokemonName;
    // Start is called before the first frame update
    void Start()
    {
        // PokeManager.Instance.RequestPokemon(pokemonName);
    }

    // Update is called once per frame
    void Update()
    {
        // OnButtonClick();
    }

    public void OnButtonClick()
    {
        string pokemonName = inputField.text;
        PokeManager.Instance.RequestPokemon(pokemonName);
    }

    public void showData(PokemonData data)
    {
        pokeName.text = data.name.ToUpper();
        pokeHeight.text = data.height.ToString();
        pokeWeight.text = data.weight.ToString();
        pokeId.text = data.id.ToString();
        pokeType.text = data.types[0].type.name;
    }
}
