using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI; 
using UnityEngine;
using UnityEngine.Networking;
using TMPro;
using System;
using Microsoft.Unity.VisualStudio.Editor;


public class PokeManager : MonoBehaviour
{
     public static PokeManager Instance;
     public DisplayAPIData displayScript; 

    //   public Image pokemonImageDisplay; 
    public UnityEngine.UI.Image pokemonImageDisplay;

    // public TextMeshProUGUI displayUI; 
    // private string url = "https://pokeapi.co/api/v2/pokemon/pikachu";

    void Awake()
    {
        if (Instance == null) 
        {
            Instance = this;
        } 
        else 
        {
            Destroy(gameObject); // Prevent duplicates
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        // StartCoroutine(GetPokemon(url));
        // RequestPokemon("charizard");
    }

    public void RequestPokemon(string pokemonName) 
    {
        string url = "https://pokeapi.co/api/v2/pokemon/" + pokemonName.ToLower();
        StartCoroutine(GetPokemon(url));
        // StartCoroutine(DownloadPokemonImage(url));
    }

    public IEnumerator GetPokemonImage(string imageurl)
    {
        using(UnityWebRequest request = UnityWebRequestTexture.GetTexture(imageurl))
        {
            yield return request.SendWebRequest();
            if(request.result == UnityWebRequest.Result.Success)
            {
                Texture2D texture2D = DownloadHandlerTexture.GetContent(request);
                pokemonImageDisplay.sprite = Sprite.Create(texture2D, new Rect(0,0,texture2D.height, texture2D.width),new Vector2(.5f,.5f),100f);
            }
        }
    }

    public IEnumerator GetPokemon(string url)
    {
        using(UnityWebRequest request = UnityWebRequest.Get(url))
        {
            yield return request.SendWebRequest();

            if(request.result == UnityWebRequest.Result.Success)
            {
                string JsonText = request.downloadHandler.text;
                PokemonData myPoke = JsonUtility.FromJson<PokemonData>(JsonText);

                
               // SEND THE DATA TO THE UI SCRIPT
                displayScript.showData(myPoke);

                // 2. Make a simple string to hold all the types
                string typeText = "";

                // 3. Look at each type in the list and add it to our text
                foreach (var t in myPoke.types) 
                {
                    typeText += t.type.name + " ";
                }


                // displayUI.text = "Pokemon" + myPoke.name;
                Debug.Log($"name : {myPoke.name} | Height : {myPoke.height} | Weight : {myPoke.weight} | ID = {myPoke.id} | Type : {typeText}");
                // Debug.Log("OK");
                // Pass the sprite URL to the image downloader
                if (!string.IsNullOrEmpty(myPoke.sprites.front_default)) 
                {
                    StartCoroutine(GetPokemonImage(myPoke.sprites.front_default));
                }
            }
            else
            {
                Debug.Log("error"+request.error);
            }
        }
    }
}
