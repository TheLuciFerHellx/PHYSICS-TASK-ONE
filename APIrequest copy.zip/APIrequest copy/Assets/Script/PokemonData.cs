
using System.Collections.Generic;

[System.Serializable]
public class PokemonData
{
    public string name;
    public int height;
    public int weight;
    public int id;
    public List<TypeEntry> types;
    public Sprites sprites;
}

[System.Serializable]
public class TypeEntry {
    public TypeInfo type; // The "inner box" for the type
}

[System.Serializable]
public class TypeInfo {
    public string name; // This is the actual name like "fire" or "water"
}

[System.Serializable]
public class Sprites {
    public string front_default; // The actual image URL
}